﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C__com_Banco_de_Dados_Musical
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;User Id=root;database=musica;password=root;";
            string query = "SELECT a.nome AS artista, al.titulo AS album\r\nFROM artistas a\r\nJOIN albuns al ON al.artista_id = a.id\r\nORDER BY a.nome, al.ano;;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlDataAdapter da = new MySqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch
                {
                    MessageBox.Show("erro");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 mus = new Form1();
            this.Hide();
            mus.ShowDialog();
        }
    }
}
